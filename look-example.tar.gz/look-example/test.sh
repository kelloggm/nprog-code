#!/bin/bash
# $1 = EXE 
# $2 = test name  
# $3 = port 
# exit 0 = success

rm -rf my.tp* my.bad1 core.* 
case $2 in
    p1) timeout 1 $1 t1 tp1 >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;
    p2) timeout 1 $1 t1 tp2 >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;
    p3) timeout 1 $1 t1 tp3 >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;
    p4) timeout 1 $1 t1 tp4 >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;
    p5) timeout 1 $1 t1 tp5 >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;
    p6) timeout 1 $1 `cat tp6` >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.2 > /dev/null 2>&1
	fi;;
    p7) timeout 1 $1 `cat tp6` words >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.2 > /dev/null 2>&1
	fi;;
    p8) timeout 1 $1 -te `cat tp6` words >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.3 > /dev/null 2>&1
	fi;;
    p9) timeout 1 $1 `cat tp6` words-out >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.4 > /dev/null 2>&1
	fi;;
    p10) timeout 1 $1 -b `cat tp6` words-out-of-order >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;
    p11) timeout 1 $1 -f `cat tp7` words >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.6 > /dev/null 2>&1
	fi;;
    p12) timeout 1 $1 `cat tp7` words >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.7 > /dev/null 2>&1
	fi;;
    p13) timeout 1 $1 -d `cat tp8` words >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.5 > /dev/null 2>&1
	fi;;
    p14) timeout 1 $1 `cat tp8` words >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;
    p15) exit 1 ;;




    n1) timeout 1 $1 t1 t1 >& my.tp
	if [ $? -eq 124 ]; then
	    exit 1
	else
	    exec diff my.tp out.1 > /dev/null 2>&1
	fi;;

 *) exit 2;;        
esac 
exit 1
